//Account constructor + methods 
console.log('Is this working');
'user strict';
var sql = require('./db.js');

//account object constructor
//define schema for items
var Account = function(account){ //unsure about this 
    this.memberID = account.memberID;
    this.password = account.password;
};
Account.create_new_account = function createUser(new_account, result) {    
    sql.query("INSERT INTO login_details set ?", new_account, function (err, res) {
        if(err) { //if there is an error
            console.log("error: ", err);
            result(err, null);
        }else{ //if there are no errors
            console.log(res.insertId);
            result(null, res.insertId); //notify me of the insertId after it has been done
        }
    });           
};

Account.log_in = function login(account, result) {
    sql.query("SELECT password FROM login_details where memberID=?", account.memberID, function(err,res){
        if(err){
            console.log("error: ", err);
            result(err, null);
        }else{
            if(res[0].password != account.password){
                console.log("Wrong password");
                result("Wrong Password", null)
            }else{
                console.log("Welcome " + account.memberID);
                result(null, account.memberID);
            }    
        }
    });
};

module.exports= Account;