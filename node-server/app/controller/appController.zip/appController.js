//functions
console.log('Is this working');
'use strict';
const Joi = require('joi');
console.log('Is this working_appController');
var express = require('express');
console.log('Is this working_appController2');

var app = express();
var accountRoutes = express.Router();
//require Account model in our routes module 

var account = require('../model/appModel.js');

accountRoutes.route('/register').post(function(req,res){
    var new_account = new account(req.body); //assigning new_account details to new_account
    const schema = {
        password: Joi.string().min(8).required()
    }
    var result = Joi.validate({password:new_account.password}, schema);
    if(result.error){ //if there is a validation error
        res.status(400).send("Your password needs to be at least 8 characters long");//bad req
        return;
    }
    if(!new_account.memberID || !new_account.password){
        res.status(400).send({ error:true, message: 'Please input memberID/password' }); //bad request
        return;
    }else{
        account.create_new_account(new_account, function(err, new_account) { //calls method in appModel.js
        if (err)
            res.send(err);
            return;
        });
        res.json(new_account);
        res.status(200).send("Registered account successfully")
    }
});

accountRoutes.route('/').post(function(req,res){ //log-in  
    account.log_in(req.body, function(err, task) { //calls method in appModel.js
    if (err){
        res.send(err);
        return;
    }
    res.json("Logged in");
    });
});

module.exports = accountRoutes;